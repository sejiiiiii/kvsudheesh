// Comrade K V Sudheesh Memorial Games - Main Application
class MemorialGamesApp {
    constructor() {
        // Initialize departments from provided data
        this.departments = [
            {
                id: "cse",
                name: "CSE",
                fullName: "Computer Science & Engineering",
                points: 0,
                color: "#FF6B6B"
            },
            {
                id: "ece", 
                name: "ECE",
                fullName: "Electronics & Communication Engineering",
                points: 0,
                color: "#4ECDC4"
            },
            {
                id: "eee",
                name: "EEE", 
                fullName: "Electrical & Electronics Engineering",
                points: 0,
                color: "#45B7D1"
            },
            {
                id: "mech",
                name: "MECH",
                fullName: "Mechanical Engineering", 
                points: 0,
                color: "#96CEB4"
            },
            {
                id: "civil",
                name: "CIVIL",
                fullName: "Civil Engineering",
                points: 0,
                color: "#FFEAA7"
            }
        ];
        
        // Admin credentials
        this.adminCredentials = {
            username: "admin",
            password: "gce2024"
        };
        
        this.activities = [];
        this.currentUser = null;
        this.isRecording = false;
        this.recognition = null;
        this.pendingConfirmation = null;
        
        // Initialize app
        this.loadData();
        this.initializeEventListeners();
        this.initializeVoiceRecognition();
        this.renderLeaderboard();
        this.renderQuickControls();
        this.renderActivityFeed();
        this.checkAuthStatus();
        
        // Add initial activity
        this.addActivity("System initialized - Memorial Games ready", "System");
    }
    
    // Data Management
    loadData() {
        try {
            const savedData = localStorage.getItem('memorialGamesData');
            if (savedData) {
                const data = JSON.parse(savedData);
                if (data.departments) {
                    this.departments = data.departments;
                }
                if (data.activities) {
                    this.activities = data.activities;
                }
            }
            
            const savedUser = localStorage.getItem('memorialGamesUser');
            if (savedUser) {
                this.currentUser = JSON.parse(savedUser);
            }
        } catch (error) {
            console.error('Error loading data:', error);
            this.showMessage('Error loading saved data', 'error');
        }
    }
    
    saveData() {
        try {
            const data = {
                departments: this.departments,
                activities: this.activities.slice(-50), // Keep last 50 activities
                timestamp: new Date().toISOString()
            };
            localStorage.setItem('memorialGamesData', JSON.stringify(data));
        } catch (error) {
            console.error('Error saving data:', error);
            this.showMessage('Error saving data', 'error');
        }
    }
    
    saveUserSession() {
        try {
            if (this.currentUser) {
                localStorage.setItem('memorialGamesUser', JSON.stringify(this.currentUser));
            } else {
                localStorage.removeItem('memorialGamesUser');
            }
        } catch (error) {
            console.error('Error saving user session:', error);
        }
    }
    
    // Authentication
    checkAuthStatus() {
        if (this.currentUser && this.currentUser.role === 'admin') {
            this.showUserControls();
            this.showAdminControls();
        } else {
            this.hideUserControls();
            this.hideAdminControls();
        }
    }
    
    login(username, password) {
        if (username === this.adminCredentials.username && password === this.adminCredentials.password) {
            this.currentUser = { username: username, role: 'admin' };
            this.saveUserSession();
            this.checkAuthStatus();
            this.closeModal('loginModal');
            this.showMessage(`Welcome Admin! You can now update scores.`, 'success');
            this.addActivity("Admin logged in", "Admin");
            return true;
        } else {
            this.showMessage('Invalid credentials. Use admin/gce2024', 'error');
            return false;
        }
    }
    
    logout() {
        const wasAdmin = this.currentUser && this.currentUser.role === 'admin';
        this.currentUser = null;
        this.saveUserSession();
        this.checkAuthStatus();
        this.showMessage('Logged out successfully', 'success');
        if (wasAdmin) {
            this.addActivity("Admin logged out", "System");
        }
    }
    
    // UI Control
    showUserControls() {
        document.getElementById('loginBtn').classList.add('hidden');
        const userStatus = document.getElementById('userStatus');
        userStatus.classList.remove('hidden');
        document.getElementById('currentUser').textContent = `Admin Mode`;
    }
    
    hideUserControls() {
        document.getElementById('loginBtn').classList.remove('hidden');
        document.getElementById('userStatus').classList.add('hidden');
    }
    
    showAdminControls() {
        document.getElementById('adminControls').classList.remove('hidden');
    }
    
    hideAdminControls() {
        document.getElementById('adminControls').classList.add('hidden');
    }
    
    // Modal Management
    showModal(modalId) {
        document.getElementById(modalId).classList.remove('hidden');
        // Focus first input if it exists
        const firstInput = document.querySelector(`#${modalId} input`);
        if (firstInput) {
            setTimeout(() => firstInput.focus(), 100);
        }
    }
    
    closeModal(modalId) {
        document.getElementById(modalId).classList.add('hidden');
        // Clear form inputs when closing modals
        const form = document.querySelector(`#${modalId} form`);
        if (form) {
            form.reset();
        }
    }
    
    // Message System
    showMessage(text, type = 'success') {
        const container = document.getElementById('messageContainer');
        const textElement = document.getElementById('messageText');
        
        textElement.textContent = text;
        container.className = `message-container ${type}`;
        container.classList.remove('hidden');
        
        // Auto-hide after 4 seconds
        setTimeout(() => {
            container.classList.add('hidden');
        }, 4000);
    }
    
    // Activity Feed
    addActivity(description, source = "Admin", method = "Manual") {
        const activity = {
            id: Date.now(),
            description,
            source,
            method,
            timestamp: new Date().toISOString(),
            timeDisplay: new Date().toLocaleTimeString()
        };
        
        this.activities.unshift(activity);
        this.activities = this.activities.slice(0, 20); // Keep last 20
        this.renderActivityFeed();
        this.saveData();
    }
    
    renderActivityFeed() {
        const feed = document.getElementById('activityFeed');
        
        if (this.activities.length === 0) {
            feed.innerHTML = `
                <div class="activity-item">
                    <span class="activity-text">System initialized - Competition ready</span>
                    <span class="activity-time">Just now</span>
                </div>
            `;
            return;
        }
        
        feed.innerHTML = this.activities.map(activity => `
            <div class="activity-item">
                <span class="activity-text">${activity.description}</span>
                <span class="activity-time">${activity.timeDisplay}</span>
            </div>
        `).join('');
    }
    
    // Leaderboard Management
    renderLeaderboard() {
        // Sort departments by points (descending), then by name for ties
        const sortedDepts = [...this.departments].sort((a, b) => {
            if (b.points !== a.points) {
                return b.points - a.points;
            }
            return a.name.localeCompare(b.name);
        });
        
        const tbody = document.getElementById('leaderboardBody');
        tbody.innerHTML = '';
        
        sortedDepts.forEach((dept, index) => {
            const row = document.createElement('tr');
            const position = index + 1;
            const positionText = this.getPositionText(position);
            
            row.innerHTML = `
                <td class="position-cell position-${position}">${positionText}</td>
                <td>
                    <strong>${dept.name}</strong><br>
                    <small>${dept.fullName}</small>
                </td>
                <td class="points-cell">${dept.points}</td>
            `;
            
            tbody.appendChild(row);
        });
    }
    
    getPositionText(position) {
        switch(position) {
            case 1: return '🥇 1st';
            case 2: return '🥈 2nd'; 
            case 3: return '🥉 3rd';
            default: return `${position}th`;
        }
    }
    
    renderQuickControls() {
        const container = document.getElementById('quickControls');
        container.innerHTML = '';
        
        this.departments.forEach(dept => {
            const controlDiv = document.createElement('div');
            controlDiv.className = 'dept-controls';
            controlDiv.innerHTML = `
                <div class="dept-name">${dept.name}</div>
                <div class="dept-buttons">
                    <button class="btn btn--add btn--small" data-dept="${dept.name}" data-points="1">+1</button>
                    <button class="btn btn--add btn--small" data-dept="${dept.name}" data-points="3">+3</button>
                    <button class="btn btn--add btn--small" data-dept="${dept.name}" data-points="5">+5</button>
                    <button class="btn btn--add btn--small" data-dept="${dept.name}" data-points="10">+10</button>
                    <button class="btn btn--subtract btn--small" data-dept="${dept.name}" data-points="-1">-1</button>
                    <button class="btn btn--subtract btn--small" data-dept="${dept.name}" data-points="-3">-3</button>
                </div>
            `;
            container.appendChild(controlDiv);
        });
    }
    
    // Point Management
    updatePoints(deptName, points, eventDescription = "", showConfirmation = true, source = "Admin", method = "Manual") {
        const dept = this.departments.find(d => d.name === deptName);
        if (!dept) {
            this.showMessage(`Department ${deptName} not found`, 'error');
            return false;
        }
        
        const newPoints = dept.points + points;
        if (newPoints < 0) {
            this.showMessage(`Cannot set negative points for ${deptName}`, 'error');
            return false;
        }
        
        const action = points > 0 ? 'add' : 'subtract';
        const absPoints = Math.abs(points);
        const pointsText = absPoints === 1 ? 'point' : 'points';
        const message = `${action === 'add' ? 'Add' : 'Subtract'} ${absPoints} ${pointsText} ${action === 'add' ? 'to' : 'from'} ${deptName}?`;
        
        if (showConfirmation) {
            this.showConfirmation(message, () => {
                this.executePointUpdate(deptName, points, eventDescription, source, method);
            });
        } else {
            this.executePointUpdate(deptName, points, eventDescription, source, method);
        }
    }
    
    executePointUpdate(deptName, points, eventDescription = "", source = "Admin", method = "Manual") {
        const dept = this.departments.find(d => d.name === deptName);
        const oldPoints = dept.points;
        dept.points += points;
        
        this.saveData();
        this.renderLeaderboard();
        
        const action = points > 0 ? 'Added' : 'Subtracted';
        const absPoints = Math.abs(points);
        const pointsText = absPoints === 1 ? 'point' : 'points';
        
        // Show success message
        this.showMessage(`${action} ${absPoints} ${pointsText} ${points > 0 ? 'to' : 'from'} ${deptName}`, 'success');
        
        // Add to activity feed
        const eventText = eventDescription ? ` for ${eventDescription}` : '';
        const activityDescription = `${deptName}: ${oldPoints} → ${dept.points} ${pointsText}${eventText}`;
        this.addActivity(activityDescription, source, method);
    }
    
    // Confirmation Dialog
    showConfirmation(message, onConfirm) {
        document.getElementById('confirmMessage').textContent = message;
        this.showModal('confirmModal');
        this.pendingConfirmation = onConfirm;
    }
    
    // Voice Recognition
    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            this.recognition.continuous = false;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-US';
            
            this.recognition.onstart = () => {
                this.isRecording = true;
                this.updateVoiceButton();
                document.getElementById('transcriptDisplay').classList.remove('hidden');
                document.getElementById('transcript').textContent = 'Listening... Speak now!';
            };
            
            this.recognition.onresult = (event) => {
                let transcript = '';
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    transcript += event.results[i][0].transcript;
                }
                document.getElementById('transcript').textContent = transcript;
                
                if (event.results[event.results.length - 1].isFinal) {
                    this.processVoiceCommand(transcript);
                }
            };
            
            this.recognition.onerror = (event) => {
                this.isRecording = false;
                this.updateVoiceButton();
                this.showMessage(`Voice recognition error: ${event.error}`, 'error');
                console.error('Speech recognition error:', event.error);
            };
            
            this.recognition.onend = () => {
                this.isRecording = false;
                this.updateVoiceButton();
            };
        } else {
            // Hide voice controls if not supported
            const voiceControls = document.querySelector('.voice-controls');
            if (voiceControls) {
                voiceControls.innerHTML = `
                    <div style="text-align: center; padding: 20px; color: #FF4444; font-weight: bold;">
                        ⚠️ Voice recognition not supported in this browser.<br>
                        Try Chrome, Edge, or Safari for voice commands.
                    </div>
                `;
            }
        }
    }
    
    toggleVoiceRecognition() {
        if (!this.recognition) {
            this.showMessage('Voice recognition not available in this browser', 'error');
            return;
        }
        
        if (this.isRecording) {
            this.recognition.stop();
        } else {
            try {
                this.recognition.start();
            } catch (error) {
                this.showMessage('Error starting voice recognition', 'error');
                console.error('Voice recognition start error:', error);
            }
        }
    }
    
    updateVoiceButton() {
        const btn = document.getElementById('voiceBtn');
        const icon = document.getElementById('voiceIcon');
        const text = document.getElementById('voiceText');
        
        if (this.isRecording) {
            btn.classList.add('recording');
            icon.textContent = '🔴';
            text.textContent = 'Recording... Click to Stop';
        } else {
            btn.classList.remove('recording');
            icon.textContent = '🎤';
            text.textContent = 'Start Voice Command';
            
            // Hide transcript after recording stops
            setTimeout(() => {
                document.getElementById('transcriptDisplay').classList.add('hidden');
            }, 3000);
        }
    }
    
    processVoiceCommand(transcript) {
        console.log('Processing voice command:', transcript);
        const lowerTranscript = transcript.toLowerCase().trim();
        
        // Enhanced voice command patterns
        const patterns = [
            // Add patterns
            { 
                regex: /(?:add|give)\s+(\d+)\s+(?:points?\s+)?(?:to\s+)?(\w+)(?:\s+for\s+(.+))?/i,
                type: 'add'
            },
            {
                regex: /(\w+)\s+(?:gets?|receives?)\s+(\d+)\s+points?(?:\s+for\s+(.+))?/i,
                type: 'add',
                swapped: true
            },
            // Subtract patterns
            {
                regex: /(?:subtract|remove|take\s+away)\s+(\d+)\s+(?:points?\s+)?(?:from\s+)?(\w+)(?:\s+for\s+(.+))?/i,
                type: 'subtract'
            },
            {
                regex: /(\w+)\s+(?:loses?)\s+(\d+)\s+points?(?:\s+for\s+(.+))?/i,
                type: 'subtract',
                swapped: true
            }
        ];
        
        let match = null;
        let matchedPattern = null;
        
        // Try each pattern
        for (const pattern of patterns) {
            match = lowerTranscript.match(pattern.regex);
            if (match) {
                matchedPattern = pattern;
                break;
            }
        }
        
        if (match && matchedPattern) {
            let points, deptInput, eventDescription;
            
            if (matchedPattern.swapped) {
                // Department comes first, then points
                deptInput = match[1];
                points = parseInt(match[2]);
                eventDescription = match[3] || "";
            } else {
                // Points come first, then department
                points = parseInt(match[1]);
                deptInput = match[2];
                eventDescription = match[3] || "";
            }
            
            const deptName = this.parseDepartmentName(deptInput);
            
            if (matchedPattern.type === 'subtract') {
                points = -points;
            }
            
            if (deptName && !isNaN(points)) {
                console.log(`Voice command parsed: ${deptName}, ${points} points, "${eventDescription}"`);
                this.updatePoints(deptName, points, eventDescription, true, "Admin", "Voice");
            } else {
                this.showMessage('Could not understand department name. Try: "Add 10 points to CSE"', 'error');
            }
        } else {
            this.showMessage('Command not recognized. Try: "Add 10 points to CSE for football match"', 'error');
        }
    }
    
    parseDepartmentName(input) {
        const inputLower = input.toLowerCase().trim();
        
        // Department name mappings
        const deptMappings = {
            'cse': 'CSE',
            'computer': 'CSE',
            'computer science': 'CSE',
            'cs': 'CSE',
            'ece': 'ECE',
            'electronics': 'ECE',
            'electronics and communication': 'ECE',
            'ec': 'ECE',
            'eee': 'EEE',
            'electrical': 'EEE',
            'electrical and electronics': 'EEE',
            'ee': 'EEE',
            'civil': 'CIVIL',
            'civil engineering': 'CIVIL',
            'ce': 'CIVIL',
            'mech': 'MECH',
            'mechanical': 'MECH',
            'mechanical engineering': 'MECH',
            'me': 'MECH'
        };
        
        return deptMappings[inputLower] || null;
    }
    
    // Data Export/Import
    exportData() {
        try {
            const data = {
                departments: this.departments,
                activities: this.activities,
                exportDate: new Date().toISOString(),
                eventName: "Comrade K V Sudheesh Memorial Games"
            };
            
            const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `memorial-games-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showMessage('Data exported successfully', 'success');
            this.addActivity("Data exported", "Admin", "Export");
        } catch (error) {
            this.showMessage('Error exporting data', 'error');
            console.error('Export error:', error);
        }
    }
    
    resetAllData() {
        this.showConfirmation('Are you sure you want to reset ALL scores to zero? This cannot be undone!', () => {
            this.departments.forEach(dept => {
                dept.points = 0;
            });
            this.activities = [];
            this.saveData();
            this.renderLeaderboard();
            this.renderActivityFeed();
            this.showMessage('All scores have been reset to zero', 'success');
            this.addActivity("All scores reset to zero", "Admin", "Reset");
        });
    }
    
    // Event Listeners
    initializeEventListeners() {
        // Login/Logout
        document.getElementById('loginBtn').addEventListener('click', () => {
            this.showModal('loginModal');
        });
        
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.logout();
        });
        
        // Login form
        document.getElementById('loginForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            this.login(username, password);
        });
        
        // Modal close buttons
        document.getElementById('closeLogin').addEventListener('click', () => {
            this.closeModal('loginModal');
        });
        
        document.getElementById('closeConfirm').addEventListener('click', () => {
            this.closeModal('confirmModal');
        });
        
        // Confirmation buttons
        document.getElementById('confirmYes').addEventListener('click', () => {
            this.closeModal('confirmModal');
            if (this.pendingConfirmation) {
                this.pendingConfirmation();
                this.pendingConfirmation = null;
            }
        });
        
        document.getElementById('confirmNo').addEventListener('click', () => {
            this.closeModal('confirmModal');
            this.pendingConfirmation = null;
        });
        
        // Manual point update
        document.getElementById('updatePointsBtn').addEventListener('click', () => {
            const dept = document.getElementById('departmentSelect').value;
            const points = parseInt(document.getElementById('pointsInput').value);
            const eventDesc = document.getElementById('eventInput').value.trim();
            
            if (!dept) {
                this.showMessage('Please select a department', 'error');
                return;
            }
            
            if (isNaN(points) || points === 0) {
                this.showMessage('Please enter a valid non-zero number', 'error');
                return;
            }
            
            if (!eventDesc) {
                this.showMessage('Please enter an event description', 'error');
                return;
            }
            
            this.updatePoints(dept, points, eventDesc);
            
            // Clear inputs after successful update
            document.getElementById('departmentSelect').value = '';
            document.getElementById('pointsInput').value = '';
            document.getElementById('eventInput').value = '';
        });
        
        // Quick controls (delegated event handling)
        document.getElementById('quickControls').addEventListener('click', (e) => {
            if (e.target.matches('button[data-dept]')) {
                const dept = e.target.dataset.dept;
                const points = parseInt(e.target.dataset.points);
                const eventDesc = `Quick ${points > 0 ? 'add' : 'subtract'} ${Math.abs(points)} points`;
                this.updatePoints(dept, points, eventDesc, false); // No confirmation for quick buttons
            }
        });
        
        // Voice recognition
        document.getElementById('voiceBtn').addEventListener('click', () => {
            this.toggleVoiceRecognition();
        });
        
        // Data management buttons
        document.getElementById('exportBtn').addEventListener('click', () => {
            this.exportData();
        });
        
        document.getElementById('resetBtn').addEventListener('click', () => {
            this.resetAllData();
        });
        
        // Message close
        document.getElementById('closeMessage').addEventListener('click', () => {
            document.getElementById('messageContainer').classList.add('hidden');
        });
        
        // Close modals on outside click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                // Close all modals and messages
                document.querySelectorAll('.modal').forEach(modal => {
                    modal.classList.add('hidden');
                });
                document.getElementById('messageContainer').classList.add('hidden');
                this.pendingConfirmation = null;
            }
        });
        
        // Auto-save on page unload
        window.addEventListener('beforeunload', () => {
            this.saveData();
        });
        
        // Auto-refresh leaderboard every 30 seconds to show time updates
        setInterval(() => {
            this.renderActivityFeed();
        }, 30000);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.memorialGames = new MemorialGamesApp();
});

// Utility functions for debugging and admin use
window.debugFunctions = {
    resetData: function() {
        if (confirm('⚠️ DANGER: Reset ALL data? This will delete everything!')) {
            localStorage.removeItem('memorialGamesData');
            localStorage.removeItem('memorialGamesUser');
            location.reload();
        }
    },
    
    addTestData: function() {
        if (window.memorialGames) {
            window.memorialGames.executePointUpdate('CSE', 25, 'Test Event 1', 'Test', 'Debug');
            window.memorialGames.executePointUpdate('ECE', 20, 'Test Event 2', 'Test', 'Debug');
            window.memorialGames.executePointUpdate('EEE', 15, 'Test Event 3', 'Test', 'Debug');
            window.memorialGames.executePointUpdate('MECH', 10, 'Test Event 4', 'Test', 'Debug');
            window.memorialGames.executePointUpdate('CIVIL', 5, 'Test Event 5', 'Test', 'Debug');
        }
    },
    
    exportData: function() {
        if (window.memorialGames) {
            window.memorialGames.exportData();
        }
    }
};

// Make debug functions available in console
console.log('🏆 Memorial Games Debug Functions Available:');
console.log('- debugFunctions.resetData() - Reset all data (DANGEROUS!)');
console.log('- debugFunctions.addTestData() - Add test scores');
console.log('- debugFunctions.exportData() - Export current data');