# 🚀 Netlify Deployment Guide - GCE Kannur Points Tracker

This guide will help you deploy your points tracker to Netlify with concurrent access support using serverless functions and a cloud database.

## 📋 Prerequisites

1. **Netlify Account**: Sign up at [netlify.com](https://netlify.com)
2. **Turso Account**: Sign up at [turso.tech](https://turso.tech) for the cloud SQLite database
3. **GitHub Account**: For code repository
4. **Node.js**: Version 16+ installed locally

## 🗄️ Step 1: Set Up Cloud Database (Turso)

### 1.1 Create Turso Database
```bash
# Install Turso CLI
curl -sSfL https://get.tur.so/install.sh | bash

# Login to Turso
turso auth login

# Create database
turso db create gce-points-tracker

# Get database URL
turso db show gce-points-tracker --url

# Create auth token
turso db tokens create gce-points-tracker
```

### 1.2 Save Database Credentials
- **Database URL**: Save the output from the `show` command
- **Auth Token**: Save the token from the `tokens create` command

## 🔧 Step 2: Prepare Your Project

### 2.1 Install Dependencies
```bash
npm install @libsql/client netlify-cli
```

### 2.2 Test Locally with Netlify Dev
```bash
# Install Netlify CLI globally
npm install -g netlify-cli

# Login to Netlify
netlify login

# Test locally (make sure to set environment variables first)
netlify dev
```

## 🌐 Step 3: Deploy to Netlify

### 3.1 Connect to GitHub
1. Push your code to a GitHub repository
2. Go to [Netlify Dashboard](https://app.netlify.com)
3. Click "New site from Git"
4. Choose GitHub and select your repository

### 3.2 Configure Build Settings
- **Build command**: `npm run build`
- **Publish directory**: `dist`
- **Functions directory**: `netlify/functions`

### 3.3 Set Environment Variables
In Netlify Dashboard → Site settings → Environment variables:

```
TURSO_DATABASE_URL=libsql://your-database-url.turso.io
TURSO_AUTH_TOKEN=your-auth-token-here
```

### 3.4 Deploy
1. Click "Deploy site"
2. Wait for build to complete
3. Your site will be available at `https://your-site-name.netlify.app`

## 🔄 Step 4: Update Frontend API Calls

Your frontend (`index.html`) needs to be updated to use the new API endpoints:

### 4.1 Update API Base URL
Change from:
```javascript
const API_BASE = 'http://localhost:3000/api';
```

To:
```javascript
const API_BASE = 'https://your-site-name.netlify.app/api';
// or for production
const API_BASE = 'https://kvsudheesh.netlify.app/api';
```

### 4.2 Update Endpoint Paths
- `GET /api/departments` → `/.netlify/functions/departments`
- `POST /api/login` → `/.netlify/functions/login`
- `POST /api/departments/:id/points` → `/.netlify/functions/update-points`
- `GET /api/activities` → `/.netlify/functions/activities`

## 📱 Step 5: Real-time Updates Alternative

Since Netlify Functions don't support WebSocket connections, here are alternatives for real-time updates:

### Option A: Polling (Recommended for simplicity)
```javascript
// Poll for updates every 5 seconds
setInterval(async () => {
    try {
        const response = await fetch('/.netlify/functions/departments');
        const data = await response.json();
        updateDepartmentTable(data.departments);
    } catch (error) {
        console.error('Error fetching updates:', error);
    }
}, 5000);
```

### Option B: Server-Sent Events (Future enhancement)
Consider implementing SSE with a service like Pusher or Ably for true real-time updates.

## 🛠️ Step 6: Domain Configuration

### 6.1 Custom Domain (Optional)
If you want to use your own domain:
1. Go to Netlify Dashboard → Domain settings
2. Add custom domain: `kvsudheesh.netlify.app` → `yourdomain.com`
3. Follow DNS configuration instructions

### 6.2 HTTPS Configuration
Netlify automatically provides SSL certificates for all sites.

## 🔍 Step 7: Testing & Monitoring

### 7.1 Test Functionality
1. Visit your deployed site
2. Test admin login (username: `admin`, password: `admin123`)
3. Test point updates
4. Verify concurrent access by opening multiple browser tabs

### 7.2 Monitor Performance
- Check Netlify Function logs in the dashboard
- Monitor database usage in Turso dashboard
- Set up error notifications

## 🚦 Step 8: Production Checklist

- [ ] Database is set up and accessible
- [ ] Environment variables are configured
- [ ] Site deploys successfully
- [ ] Admin login works
- [ ] Points can be updated
- [ ] Multiple users can access simultaneously
- [ ] Mobile responsiveness works
- [ ] HTTPS is enabled
- [ ] Performance is acceptable

## 🛡️ Security Considerations

1. **Change Default Credentials**: Update the default admin password
2. **Environment Variables**: Never commit secrets to git
3. **Database Access**: Turso tokens have built-in security
4. **HTTPS Only**: Netlify enforces HTTPS by default

## 📞 Support & Troubleshooting

### Common Issues:

1. **Build Fails**: Check build logs in Netlify dashboard
2. **Functions Error**: Check function logs and environment variables
3. **Database Connection**: Verify Turso credentials and database URL
4. **CORS Issues**: Functions include proper CORS headers

### Getting Help:
- Netlify Documentation: [docs.netlify.com](https://docs.netlify.com)
- Turso Documentation: [docs.turso.tech](https://docs.turso.tech)
- GitHub Issues: Create issues in your repository

## 🎉 Congratulations!

Your GCE Kannur Points Tracker is now deployed and ready for concurrent access at:
**https://kvsudheesh.netlify.app**

The system supports:
✅ Multiple simultaneous users  
✅ Real-time data persistence  
✅ Admin authentication  
✅ Point updates and tracking  
✅ Mobile-friendly interface  
✅ Automatic HTTPS  
✅ Global CDN distribution  

---

*Need help? Check the troubleshooting section or create an issue in the repository.*
