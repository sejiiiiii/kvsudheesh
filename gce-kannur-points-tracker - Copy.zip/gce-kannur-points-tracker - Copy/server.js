const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = process.env.PORT || 3000;
const dbPath = path.join(__dirname, 'gce-tracker.db');

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('.'));

// Database connection
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Error opening database:', err.message);
    } else {
        console.log('🗄️  Connected to SQLite database');
    }
});

// WebSocket connections storage
const clients = new Set();

// WebSocket connection handler
wss.on('connection', (ws) => {
    console.log('🔗 New client connected');
    clients.add(ws);
    
    // Send current data to new client
    getCurrentData((data) => {
        ws.send(JSON.stringify({
            type: 'initial_data',
            data: data
        }));
    });

    ws.on('close', () => {
        console.log('🔌 Client disconnected');
        clients.delete(ws);
    });

    ws.on('error', (error) => {
        console.error('❌ WebSocket error:', error);
        clients.delete(ws);
    });
});

// Broadcast to all connected clients
function broadcast(data) {
    const message = JSON.stringify(data);
    clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
}

// Get current departments and activities
function getCurrentData(callback) {
    db.all(`SELECT * FROM departments ORDER BY points DESC`, (err, departments) => {
        if (err) {
            console.error('❌ Error fetching departments:', err);
            callback(null);
            return;
        }
        
        db.all(`SELECT * FROM activities ORDER BY timestamp DESC LIMIT 10`, (err, activities) => {
            if (err) {
                console.error('❌ Error fetching activities:', err);
                callback({ departments, activities: [] });
                return;
            }
            
            callback({ departments, activities });
        });
    });
}

// API Routes

// Get all departments
app.get('/api/departments', (req, res) => {
    db.all(`SELECT * FROM departments ORDER BY points DESC`, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ departments: rows });
    });
});

// Get recent activities
app.get('/api/activities', (req, res) => {
    const limit = req.query.limit || 10;
    db.all(`SELECT * FROM activities ORDER BY timestamp DESC LIMIT ?`, [limit], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ activities: rows });
    });
});

// User login
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
    }
    
    db.get(`SELECT * FROM users WHERE username = ? AND password_hash = ?`, 
        [username, password], (err, user) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        // Update last login
        db.run(`UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?`, [user.id]);
        
        res.json({ 
            success: true, 
            user: { 
                id: user.id, 
                username: user.username, 
                role: user.role 
            },
            token: uuidv4() // Simple token for demo
        });
    });
});

// Update department points
app.post('/api/departments/:id/points', (req, res) => {
    const departmentId = req.params.id;
    const { pointsChange, eventDescription, updatedBy, method } = req.body;
    
    if (!pointsChange || !eventDescription || !updatedBy) {
        return res.status(400).json({ 
            error: 'Points change, event description, and updated by are required' 
        });
    }
    
    // Start transaction
    db.serialize(() => {
        db.run('BEGIN TRANSACTION');
        
        // Get current points
        db.get(`SELECT * FROM departments WHERE id = ?`, [departmentId], (err, dept) => {
            if (err) {
                db.run('ROLLBACK');
                return res.status(500).json({ error: err.message });
            }
            
            if (!dept) {
                db.run('ROLLBACK');
                return res.status(404).json({ error: 'Department not found' });
            }
            
            const newPoints = Math.max(0, dept.points + parseInt(pointsChange));
            
            // Update department points
            db.run(`UPDATE departments SET points = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, 
                [newPoints, departmentId], (err) => {
                if (err) {
                    db.run('ROLLBACK');
                    return res.status(500).json({ error: err.message });
                }
                
                // Add activity record
                db.run(`INSERT INTO activities 
                    (department_id, department_name, points_changed, event_description, updated_by, method)
                    VALUES (?, ?, ?, ?, ?, ?)`, 
                    [departmentId, dept.name, pointsChange, eventDescription, updatedBy, method || 'manual'], 
                    (err) => {
                    if (err) {
                        db.run('ROLLBACK');
                        return res.status(500).json({ error: err.message });
                    }
                    
                    db.run('COMMIT');
                    
                    // Broadcast update to all clients
                    getCurrentData((data) => {
                        if (data) {
                            broadcast({
                                type: 'points_updated',
                                data: data,
                                updatedDepartment: departmentId,
                                pointsChange: pointsChange
                            });
                        }
                    });
                    
                    res.json({ 
                        success: true, 
                        message: 'Points updated successfully',
                        newPoints: newPoints 
                    });
                });
            });
        });
    });
});

// Get department details with activities
app.get('/api/departments/:id', (req, res) => {
    const departmentId = req.params.id;
    
    db.get(`SELECT * FROM departments WHERE id = ?`, [departmentId], (err, dept) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        
        if (!dept) {
            return res.status(404).json({ error: 'Department not found' });
        }
        
        // Get recent activities for this department
        db.all(`SELECT * FROM activities WHERE department_id = ? ORDER BY timestamp DESC LIMIT 10`, 
            [departmentId], (err, activities) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            
            res.json({ 
                department: dept, 
                activities: activities 
            });
        });
    });
});

// Export data
app.get('/api/export', (req, res) => {
    getCurrentData((data) => {
        if (!data) {
            return res.status(500).json({ error: 'Failed to export data' });
        }
        
        const exportData = {
            ...data,
            exportedAt: new Date().toISOString(),
            exportedBy: req.query.user || 'system'
        };
        
        res.json(exportData);
    });
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        connectedClients: clients.size 
    });
});

// Serve index.html for root path
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Start server
server.listen(PORT, () => {
    console.log(`🚀 GCE Kannur Points Tracker Server running on port ${PORT}`);
    console.log(`📡 WebSocket server ready for real-time updates`);
    console.log(`🌐 Access the app at: http://localhost:${PORT}`);
    console.log(`🔗 API endpoints available at: http://localhost:${PORT}/api/`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down server...');
    
    // Close WebSocket connections
    clients.forEach((client) => {
        client.close();
    });
    
    // Close database connection
    db.close((err) => {
        if (err) {
            console.error('❌ Error closing database:', err.message);
        } else {
            console.log('✅ Database connection closed');
        }
        process.exit(0);
    });
});
