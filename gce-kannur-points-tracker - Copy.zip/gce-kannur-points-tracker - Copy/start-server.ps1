# GCE Kannur Points Tracker Server Launcher
Write-Host "🚀 Starting GCE Kannur Points Tracker Server..." -ForegroundColor Green
Write-Host "📍 Server will be available at: http://localhost:3000" -ForegroundColor Cyan
Write-Host "🔗 API endpoints at: http://localhost:3000/api/" -ForegroundColor Cyan
Write-Host ""

# Change to the correct directory
Set-Location "C:\Users\USER\gce-kannur-points-tracker"

# Function to start server with auto-restart
function Start-ServerWithRestart {
    while ($true) {
        try {
            Write-Host "🟢 Starting Node.js server..." -ForegroundColor Green
            Start-Process -FilePath "node" -ArgumentList "server.js" -Wait -NoNewWindow
        }
        catch {
            Write-Host "❌ Server crashed: $_" -ForegroundColor Red
        }
        
        Write-Host "🔄 Restarting server in 3 seconds..." -ForegroundColor Yellow
        Start-Sleep -Seconds 3
    }
}

# Start the server
try {
    Start-ServerWithRestart
}
catch {
    Write-Host "❌ Failed to start server: $_" -ForegroundColor Red
    Read-Host "Press Enter to exit"
}
