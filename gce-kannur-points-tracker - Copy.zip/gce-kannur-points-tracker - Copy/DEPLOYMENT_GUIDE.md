# GCE Kannur Points Tracker - Deployment Guide

## 🚀 Quick Start (Local)

### Option 1: Using Windows Batch (Recommended for local testing)
```bash
# Double-click or run:
start-server.bat
```

### Option 2: Using PowerShell
```powershell
# Run in PowerShell:
.\start-server.ps1
```

### Option 3: Manual Node.js
```bash
npm install
node init-database.js
node server.js
```

---

## 🌐 Keeping the Site Live 24/7

### **Local Options (Development)**

#### 1. **Windows Task Scheduler (Runs on PC startup)**
1. Open Task Scheduler (`taskschd.msc`)
2. Create Basic Task → Name: "GCE Points Tracker"
3. Trigger: "When the computer starts"
4. Action: "Start a program"
   - Program: `C:\Users\USER\gce-kannur-points-tracker\start-server.bat`
   - Start in: `C:\Users\USER\gce-kannur-points-tracker`
5. Check "Run with highest privileges"

#### 2. **Windows Service with PM2**
```bash
# Install PM2 globally
npm install -g pm2
npm install -g pm2-windows-service

# Start your app with PM2
pm2 start server.js --name "gce-points-tracker"

# Install as Windows service
pm2-service-install
pm2 save
```

### **Cloud Hosting Options (Production)**

#### 1. **Heroku (Free Tier Available)**
```bash
# Install Heroku CLI, then:
git init
git add .
git commit -m "Initial commit"

heroku create gce-kannur-points-tracker
heroku config:set NODE_ENV=production
git push heroku main
```

**Required files for Heroku:**
- Add to `package.json`:
```json
{
  "engines": {
    "node": "18.x"
  },
  "scripts": {
    "start": "node server.js"
  }
}
```

#### 2. **Railway (Easy deployment)**
1. Visit [railway.app](https://railway.app)
2. Connect GitHub repository
3. Auto-deploys on git push
4. Free tier: 500 hours/month

#### 3. **Render (Free tier)**
1. Visit [render.com](https://render.com)
2. Connect GitHub repository
3. Set build command: `npm install`
4. Set start command: `node server.js`

#### 4. **Vercel (Serverless)**
```bash
npm install -g vercel
vercel --prod
```

#### 5. **Netlify (Static + Functions)**
- Deploy frontend to Netlify
- Use Netlify Functions for backend API

#### 6. **DigitalOcean App Platform**
1. Create account at [digitalocean.com](https://digitalocean.com)
2. Use App Platform
3. Connect GitHub repository
4. $5/month for basic plan

#### 7. **AWS EC2 (Most flexible)**
1. Launch EC2 instance (t2.micro is free tier)
2. Install Node.js and PM2
3. Use PM2 to manage the process
4. Set up reverse proxy with nginx

---

## 📱 Mobile Access & PWA

The app is already configured as a Progressive Web App (PWA):

### Install on Mobile:
1. Open `http://your-domain.com` in mobile browser
2. Tap "Add to Home Screen" when prompted
3. App will work offline and feel like native app

### Install on Desktop:
1. Chrome: Click install button in address bar
2. Edge: Settings → Install this site as an app

---

## 🔒 Security & Production Settings

### Environment Variables
Create `.env` file:
```
NODE_ENV=production
PORT=3000
DB_PATH=./gce-tracker.db
ADMIN_PASSWORD=your-secure-password
```

### Update server.js for production:
```javascript
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

if (isProduction) {
    // Add security headers, rate limiting, etc.
}
```

---

## 🌍 Custom Domain Setup

### For Cloud Hosting:
1. **Heroku**: Add custom domain in dashboard
2. **Railway**: Custom domain in project settings
3. **Render**: Custom domain in service settings

### DNS Configuration:
- Add CNAME record pointing to your hosting provider
- Example: `points.gcekannur.edu.in` → `your-app.herokuapp.com`

---

## 📊 Monitoring & Maintenance

### Health Checks:
- Built-in health endpoint: `/api/health`
- Use UptimeRobot or similar for monitoring

### Database Backups:
```bash
# Create backup
cp gce-tracker.db backups/backup-$(date +%Y%m%d).db

# Scheduled backup (Windows Task Scheduler)
# Create task to run backup script daily
```

### Log Management:
```javascript
// Add to server.js
const winston = require('winston');
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    transports: [
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
});
```

---

## 🚨 Troubleshooting

### Server Won't Start:
1. Check if port 3000 is already in use: `netstat -an | findstr :3000`
2. Kill existing processes: `taskkill /f /im node.exe`
3. Check database file permissions
4. Verify Node.js version: `node --version`

### Can't Connect from Other Devices:
1. Check Windows Firewall
2. Update server to bind to all interfaces:
   ```javascript
   server.listen(PORT, '0.0.0.0', () => {
       console.log(`Server running on port ${PORT}`);
   });
   ```

### Database Issues:
1. Reinitialize: `node init-database.js`
2. Check file permissions on `gce-tracker.db`
3. Verify SQLite3 installation: `npm list sqlite3`

---

## 📞 Quick Support Commands

```bash
# Check server status
curl http://localhost:3000/api/health

# Restart server (if using PM2)
pm2 restart gce-points-tracker

# View logs (if using PM2)
pm2 logs gce-points-tracker

# Update and restart
git pull origin main
npm install
pm2 restart gce-points-tracker
```

---

## 🎯 Recommended Production Setup

**For College/Institution Use:**

1. **Hosting**: Railway or Render (easy, reliable)
2. **Domain**: Custom subdomain (e.g., points.gcekannur.edu.in)
3. **Monitoring**: UptimeRobot for 24/7 monitoring
4. **Backups**: Daily database backups
5. **Updates**: GitHub workflow for easy updates

**Total Cost**: $0-5/month depending on hosting choice

---

## 🔗 Quick Links

- **Local Server**: http://localhost:3000
- **API Documentation**: http://localhost:3000/api/health
- **Admin Login**: admin / gce2024
- **Database File**: `gce-tracker.db`

---

*Need help? Check the troubleshooting section or create an issue on GitHub.*
