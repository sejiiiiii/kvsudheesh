const { createClient } = require('@libsql/client');

let client = null;

function getDbClient() {
    if (!client) {
        const dbUrl = process.env.TURSO_DATABASE_URL || process.env.DATABASE_URL;
        const authToken = process.env.TURSO_AUTH_TOKEN || process.env.DATABASE_AUTH_TOKEN;
        
        if (!dbUrl) {
            throw new Error('Database URL is required. Set TURSO_DATABASE_URL environment variable.');
        }
        
        client = createClient({
            url: dbUrl,
            authToken: authToken
        });
    }
    return client;
}

async function initializeDatabase() {
    const db = getDbClient();
    
    try {
        // Create departments table
        await db.execute(`
            CREATE TABLE IF NOT EXISTS departments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                points INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Create activities table
        await db.execute(`
            CREATE TABLE IF NOT EXISTS activities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                department_id INTEGER,
                department_name TEXT,
                points_changed INTEGER,
                event_description TEXT,
                updated_by TEXT,
                method TEXT DEFAULT 'manual',
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (department_id) REFERENCES departments (id)
            )
        `);

        // Create users table
        await db.execute(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'admin',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_login DATETIME
            )
        `);

        // Insert default departments if they don't exist
        const departments = [
            'Computer Science and Engineering',
            'Electronics and Communication',
            'Electrical and Electronics',
            'Mechanical Engineering',
            'Civil Engineering'
        ];

        for (const dept of departments) {
            await db.execute(
                'INSERT OR IGNORE INTO departments (name, points) VALUES (?, 0)',
                [dept]
            );
        }

        // Insert default admin user if it doesn't exist
        await db.execute(
            'INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, ?)',
            ['admin', 'admin123', 'admin']
        );

        console.log('✅ Database initialized successfully');
        return true;
    } catch (error) {
        console.error('❌ Database initialization error:', error);
        throw error;
    }
}

async function getCurrentData() {
    const db = getDbClient();
    
    try {
        const departments = await db.execute('SELECT * FROM departments ORDER BY points DESC');
        const activities = await db.execute('SELECT * FROM activities ORDER BY timestamp DESC LIMIT 10');
        
        return {
            departments: departments.rows,
            activities: activities.rows
        };
    } catch (error) {
        console.error('❌ Error fetching current data:', error);
        return null;
    }
}

module.exports = {
    getDbClient,
    initializeDatabase,
    getCurrentData
};
