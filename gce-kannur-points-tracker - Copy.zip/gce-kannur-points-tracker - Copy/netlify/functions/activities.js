const { getDbClient, initializeDatabase } = require('./utils/database');

const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
};

exports.handler = async (event, context) => {
    // Handle CORS preflight requests
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: ''
        };
    }

    if (event.httpMethod !== 'GET') {
        return {
            statusCode: 405,
            headers,
            body: JSON.stringify({ error: 'Method not allowed' })
        };
    }

    try {
        await initializeDatabase();
        
        const db = getDbClient();
        const urlParams = new URLSearchParams(event.queryStringParameters || {});
        const limit = urlParams.get('limit') || '10';
        
        const result = await db.execute(
            'SELECT * FROM activities ORDER BY timestamp DESC LIMIT ?',
            [parseInt(limit)]
        );
        
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ activities: result.rows })
        };
        
    } catch (error) {
        console.error('Activities error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: error.message })
        };
    }
};
