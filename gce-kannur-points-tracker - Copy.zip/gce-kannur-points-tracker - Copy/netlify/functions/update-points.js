const { getDbClient, initializeDatabase } = require('./utils/database');

const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
};

exports.handler = async (event, context) => {
    // Handle CORS preflight requests
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: ''
        };
    }

    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            headers,
            body: JSON.stringify({ error: 'Method not allowed' })
        };
    }

    try {
        await initializeDatabase();
        
        const { departmentId, pointsChange, eventDescription, updatedBy, method } = JSON.parse(event.body);
        
        if (!departmentId || !pointsChange || !eventDescription || !updatedBy) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ 
                    error: 'Department ID, points change, event description, and updated by are required' 
                })
            };
        }
        
        const db = getDbClient();
        
        // Start transaction by getting current department info
        const deptResult = await db.execute(
            'SELECT * FROM departments WHERE id = ?',
            [departmentId]
        );
        
        if (deptResult.rows.length === 0) {
            return {
                statusCode: 404,
                headers,
                body: JSON.stringify({ error: 'Department not found' })
            };
        }
        
        const dept = deptResult.rows[0];
        const newPoints = Math.max(0, dept.points + parseInt(pointsChange));
        
        // Use batch execution for transaction-like behavior
        const batch = [
            {
                sql: 'UPDATE departments SET points = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                args: [newPoints, departmentId]
            },
            {
                sql: 'INSERT INTO activities (department_id, department_name, points_changed, event_description, updated_by, method) VALUES (?, ?, ?, ?, ?, ?)',
                args: [departmentId, dept.name, pointsChange, eventDescription, updatedBy, method || 'manual']
            }
        ];
        
        await db.batch(batch);
        
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                success: true,
                message: 'Points updated successfully',
                newPoints: newPoints
            })
        };
        
    } catch (error) {
        console.error('Update points error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: error.message })
        };
    }
};
