const fs = require('fs');
const path = require('path');

// Create dist directory if it doesn't exist
const distDir = path.join(__dirname, 'dist');
if (!fs.existsSync(distDir)) {
    fs.mkdirSync(distDir, { recursive: true });
}

// Files to copy to dist
const filesToCopy = [
    'index.html',
    'styles.css',
    'manifest.json',
    'kv1.png'
];

// Special handling for app.js - use Netlify version
const specialFiles = {
    'app-netlify.js': 'app.js' // Copy app-netlify.js as app.js
};

// Copy files
filesToCopy.forEach(file => {
    const srcPath = path.join(__dirname, file);
    const destPath = path.join(distDir, file);
    
    if (fs.existsSync(srcPath)) {
        fs.copyFileSync(srcPath, destPath);
        console.log(`✅ Copied ${file} to dist/`);
    } else {
        console.warn(`⚠️  ${file} not found, skipping...`);
    }
});

// Copy special files
Object.entries(specialFiles).forEach(([srcFile, destFile]) => {
    const srcPath = path.join(__dirname, srcFile);
    const destPath = path.join(distDir, destFile);
    
    if (fs.existsSync(srcPath)) {
        fs.copyFileSync(srcPath, destPath);
        console.log(`✅ Copied ${srcFile} as ${destFile} to dist/`);
    } else {
        console.warn(`⚠️  ${srcFile} not found, skipping...`);
    }
});

console.log('🎉 Build complete!');
