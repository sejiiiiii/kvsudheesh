const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Create database
const dbPath = path.join(__dirname, 'gce-tracker.db');
const db = new sqlite3.Database(dbPath);

console.log('Initializing GCE Kannur Points Tracker Database...');

db.serialize(() => {
    // Create departments table
    db.run(`CREATE TABLE IF NOT EXISTS departments (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        fullName TEXT NOT NULL,
        points INTEGER DEFAULT 0,
        color TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Create activities table for tracking all point changes
    db.run(`CREATE TABLE IF NOT EXISTS activities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        department_id TEXT NOT NULL,
        department_name TEXT NOT NULL,
        points_changed INTEGER NOT NULL,
        event_description TEXT NOT NULL,
        updated_by TEXT NOT NULL,
        method TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (department_id) REFERENCES departments(id)
    )`);

    // Create users table for admin authentication
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'admin',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME
    )`);

    // Insert default departments
    const departments = [
        ['cse', 'CSE', 'Computer Science & Engineering', 0, '#FF6B6B'],
        ['ece', 'ECE', 'Electronics & Communication', 0, '#4ECDC4'],
        ['eee', 'EEE', 'Electrical & Electronics', 0, '#45B7D1'],
        ['mech', 'MECH', 'Mechanical Engineering', 0, '#96CEB4'],
        ['civil', 'CIVIL', 'Civil Engineering', 0, '#FFEAA7']
    ];

    const insertDept = db.prepare(`INSERT OR IGNORE INTO departments 
        (id, name, fullName, points, color) VALUES (?, ?, ?, ?, ?)`);
    
    departments.forEach(dept => {
        insertDept.run(dept);
    });
    insertDept.finalize();

    // Insert default admin user (password: gce2024)
    // In production, use proper password hashing like bcrypt
    db.run(`INSERT OR IGNORE INTO users (username, password_hash, role) 
            VALUES ('admin', 'gce2024', 'admin')`);

    console.log('✅ Database initialized successfully!');
    console.log('📊 Default departments created');
    console.log('👤 Admin user created (username: admin, password: gce2024)');
    console.log('🗄️  Database file: gce-tracker.db');
});

db.close((err) => {
    if (err) {
        console.error('❌ Error closing database:', err.message);
    } else {
        console.log('✅ Database connection closed.');
    }
});
